# Sona Learn - E-Learning Platform

Sona Learn is a full-stack MERN application designed for college e-learning. The platform allows faculty to upload video lectures and study materials, while students can access these resources along with common courses available to all.

## Features

- **User Authentication**: JWT-based authentication with role-based access control
- **Faculty Dashboard**: Upload and manage video lectures and study materials
- **Student Dashboard**: Access faculty-uploaded content
- **Common Courses**: Additional courses available to all registered students
- **Responsive Design**: Works well on mobile, tablet, and desktop

## Tech Stack

- **Frontend**: React.js with TypeScript, Tailwind CSS, Framer Motion
- **Backend**: Node.js, Express
- **Database**: MongoDB with Mongoose
- **Authentication**: JWT
- **File Storage**: Local storage (can be extended to use cloud storage)

## Getting Started

### Prerequisites

- Node.js (v14+)
- MongoDB (local or Atlas URI)

### Installation

1. Clone the repository
```bash
git clone https://github.com/yourusername/sona-learn.git
cd sona-learn
```

2. Install dependencies
```bash
npm install
```

3. Set up environment variables
```bash
cp .env.example .env
```
Edit the `.env` file with your MongoDB connection string and JWT secret.

4. Start the development server
```bash
# Run frontend and backend concurrently
npm run dev:all

# Or run them separately
npm run dev            # Frontend only
npm run dev:server     # Backend only
```

## Project Structure

```
sona-learn/
├── public/            # Static files
├── server/            # Backend code
│   ├── middleware/    # Express middleware
│   ├── models/        # MongoDB models
│   ├── routes/        # API routes
│   ├── utils/         # Helper utilities
│   └── index.js       # Server entry point
├── src/               # Frontend code
│   ├── components/    # React components
│   ├── context/       # Context API
│   ├── pages/         # Page components
│   ├── config/        # Configuration files
│   ├── App.tsx        # Main component
│   └── main.tsx       # Entry point
└── uploads/           # Uploaded files storage
```

## API Routes

### Authentication
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - User login

### Courses
- `GET /api/courses` - Get all courses
- `GET /api/courses/common` - Get common courses
- `GET /api/courses/:id` - Get course by ID
- `POST /api/courses` - Create a course (Faculty only)
- `PUT /api/courses/:id` - Update a course (Faculty only)
- `DELETE /api/courses/:id` - Delete a course (Faculty only)
- `GET /api/courses/faculty/me` - Get faculty courses
- `GET /api/courses/enrolled/me` - Get student enrolled courses
- `POST /api/courses/:id/enroll` - Enroll in a course

### Lessons
- `POST /api/lessons/courses/:courseId/sections` - Add a section to course
- `POST /api/lessons/courses/:courseId/sections/:sectionId` - Add a lesson to section
- `DELETE /api/lessons/courses/:courseId/sections/:sectionId/lessons/:lessonId` - Delete a lesson

## License

MIT

## Contributors

- Your Name - Initial work