// API base URL - modify this for production
export const apiBaseUrl = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

// Video player configuration
export const videoPlayerConfig = {
  controls: true,
  width: '100%',
  height: 'auto',
  playing: false,
  pip: true,
};

// File upload limits
export const maxFileSize = 100 * 1024 * 1024; // 100MB
export const allowedVideoFormats = ['.mp4', '.webm', '.ogg'];
export const allowedDocumentFormats = ['.pdf', '.doc', '.docx', '.ppt', '.pptx'];