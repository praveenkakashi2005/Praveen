import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { BookOpen, Users, Video, Book, Phone, Mail, MapPin } from 'lucide-react';
import AnimatedBackground from '../components/AnimatedBackground';

const HomePage: React.FC = () => {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        delayChildren: 0.3,
        staggerChildren: 0.2
      }
    }
  };
  
  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: { duration: 0.5 }
    }
  };

  return (
    <>
      <AnimatedBackground>
        <div className="container mx-auto px-4 pt-24 pb-16">
          <div className="min-h-[85vh] flex flex-col justify-center items-center text-center text-white">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7 }}
              className="max-w-4xl"
            >
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6">
                Welcome to{' '}
                <span className="text-secondary-400">Sona Learn</span>
              </h1>
              
              <p className="text-xl md:text-2xl mb-8 text-gray-200">
                Your college e-learning platform for academic excellence
              </p>
              
              <div className="flex flex-wrap justify-center gap-4">
                <Link to="/register" className="btn btn-secondary px-8 py-3 text-lg">
                  Join Now
                </Link>
                <Link to="/common-courses" className="btn btn-outline border-white text-white hover:bg-white/10 px-8 py-3 text-lg">
                  Browse Courses
                </Link>
              </div>
            </motion.div>
          </div>
        </div>
      </AnimatedBackground>
      
      {/* Features Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.3 }}
            variants={containerVariants}
            className="text-center mb-12"
          >
            <motion.h2 
              variants={itemVariants}
              className="text-3xl font-bold text-dark-700 mb-4"
            >
              Why Choose Sona Learn?
            </motion.h2>
            <motion.p 
              variants={itemVariants}
              className="text-lg text-gray-600 max-w-2xl mx-auto"
            >
              Our platform is designed specifically for college education, providing a comprehensive learning experience.
            </motion.p>
          </motion.div>
          
          <motion.div 
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.1 }}
            variants={containerVariants}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8"
          >
            <motion.div variants={itemVariants} className="bg-gray-50 p-6 rounded-lg text-center">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-primary-100 text-primary-600 rounded-full mb-4">
                <Video size={32} />
              </div>
              <h3 className="text-xl font-semibold text-dark-700 mb-2">Faculty Lectures</h3>
              <p className="text-gray-600">Access video lectures from your professors anytime, anywhere.</p>
            </motion.div>
            
            <motion.div variants={itemVariants} className="bg-gray-50 p-6 rounded-lg text-center">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-secondary-100 text-secondary-600 rounded-full mb-4">
                <Book size={32} />
              </div>
              <h3 className="text-xl font-semibold text-dark-700 mb-2">Study Materials</h3>
              <p className="text-gray-600">Download and access course materials and resources with ease.</p>
            </motion.div>
            
            <motion.div variants={itemVariants} className="bg-gray-50 p-6 rounded-lg text-center">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-primary-100 text-primary-600 rounded-full mb-4">
                <BookOpen size={32} />
              </div>
              <h3 className="text-xl font-semibold text-dark-700 mb-2">Common Courses</h3>
              <p className="text-gray-600">Explore additional courses available to all students to enhance your learning.</p>
            </motion.div>
            
            <motion.div variants={itemVariants} className="bg-gray-50 p-6 rounded-lg text-center">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-secondary-100 text-secondary-600 rounded-full mb-4">
                <Users size={32} />
              </div>
              <h3 className="text-xl font-semibold text-dark-700 mb-2">College Community</h3>
              <p className="text-gray-600">Connect with your college community in a secure educational environment.</p>
            </motion.div>
          </motion.div>
        </div>
      </section>
      
      {/* Contact Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-dark-700 mb-4">Contact Us</h2>
            <p className="text-lg text-gray-600">Get in touch with us for any queries or support</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            <div className="bg-white p-6 rounded-lg shadow-sm text-center">
              <Phone size={32} className="mx-auto mb-4 text-primary-600" />
              <h3 className="font-semibold text-dark-700 mb-2">Phone</h3>
              <p className="text-gray-600">+91 6381650926</p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-sm text-center">
              <Mail size={32} className="mx-auto mb-4 text-primary-600" />
              <h3 className="font-semibold text-dark-700 mb-2">Email</h3>
              <p className="text-gray-600">sona.AIML@sonatech.ac.in</p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-sm text-center">
              <MapPin size={32} className="mx-auto mb-4 text-primary-600" />
              <h3 className="font-semibold text-dark-700 mb-2">Address</h3>
              <p className="text-gray-600">Sona College of Technology<br />Salem-636005</p>
            </div>
          </div>
        </div>
      </section>
      
      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-r from-primary-700 to-primary-900 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-6">Ready to enhance your learning experience?</h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            Join Sona Learn today and access quality educational content from your college faculty.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Link to="/register" className="btn bg-white text-primary-700 hover:bg-gray-100 px-8 py-3 text-lg">
              Get Started
            </Link>
            <Link to="/login" className="btn border-2 border-white text-white hover:bg-white/10 px-8 py-3 text-lg">
              Login
            </Link>
          </div>
        </div>
      </section>
      
      {/* Footer */}
      <footer className="bg-dark-800 text-white py-10">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center mb-4 md:mb-0">
              <BookOpen size={24} className="mr-2" />
              <span className="text-xl font-bold">Sona Learn</span>
            </div>
            <div className="text-gray-400 text-sm">
              © {new Date().getFullYear()} Sona Learn. All rights reserved.
            </div>
          </div>
        </div>
      </footer>
    </>
  );
};

export default HomePage;