import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { BookOpen, Search, Clock, Video } from 'lucide-react';
import CourseCard from '../components/CourseCard';
import { useAuth } from '../context/AuthContext';

// Mock data - would be fetched from API in a real app
const mockCourses = [
  {
    id: '1',
    title: 'Introduction to Computer Science',
    description: 'Learn the fundamentals of computer science and programming',
    instructor: 'Prof. Alan Turing',
    duration: '8 weeks',
    thumbnail: 'https://images.pexels.com/photos/546819/pexels-photo-546819.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
  },
  {
    id: '2',
    title: 'Data Structures and Algorithms',
    description: 'Master essential data structures and algorithm design techniques',
    instructor: 'Dr. Ada Lovelace',
    duration: '10 weeks',
    thumbnail: 'https://images.pexels.com/photos/577585/pexels-photo-577585.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
  },
  {
    id: '3',
    title: 'Web Development Fundamentals',
    description: 'Build modern web applications with HTML, CSS, and JavaScript',
    instructor: 'Prof. Tim Berners-Lee',
    duration: '6 weeks',
    thumbnail: 'https://images.pexels.com/photos/270348/pexels-photo-270348.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
  },
  {
    id: '4',
    title: 'Database Management Systems',
    description: 'Learn how to design, implement, and manage databases',
    instructor: 'Dr. Edgar Codd',
    duration: '7 weeks',
    thumbnail: 'https://images.pexels.com/photos/4050315/pexels-photo-4050315.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
  }
];

// Recent activity mock data
const recentActivities = [
  { id: 1, course: 'Introduction to Computer Science', date: '2 hours ago', type: 'video', title: 'Lecture 3: Control Structures' },
  { id: 2, course: 'Data Structures and Algorithms', date: 'Yesterday', type: 'document', title: 'Assignment 2: Binary Trees' },
  { id: 3, course: 'Web Development Fundamentals', date: '3 days ago', type: 'video', title: 'Lecture 1: HTML Basics' }
];

// Dashboard stats mock data
const dashboardStats = [
  { id: 1, label: 'Enrolled Courses', value: '4', icon: BookOpen, color: 'bg-primary-100 text-primary-600' },
  { id: 2, label: 'Hours Learned', value: '28', icon: Clock, color: 'bg-secondary-100 text-secondary-600' },
  { id: 3, label: 'Videos Watched', value: '24', icon: Video, color: 'bg-green-100 text-green-600' }
];

const StudentDashboard: React.FC = () => {
  const { user } = useAuth();
  const [searchTerm, setSearchTerm] = useState('');
  const [filteredCourses, setFilteredCourses] = useState(mockCourses);
  
  // Filter courses based on search term
  useEffect(() => {
    if (!searchTerm.trim()) {
      setFilteredCourses(mockCourses);
      return;
    }
    
    const filtered = mockCourses.filter(course => 
      course.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      course.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      course.instructor.toLowerCase().includes(searchTerm.toLowerCase())
    );
    
    setFilteredCourses(filtered);
  }, [searchTerm]);

  return (
    <div className="pt-20 pb-10">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="bg-gradient-to-r from-primary-700 to-primary-800 text-white rounded-lg p-6 mb-8 shadow-md">
          <h1 className="text-2xl font-bold mb-2">Welcome, {user?.name}</h1>
          <p className="opacity-90">Continue your learning journey from where you left off.</p>
        </div>
        
        {/* Dashboard Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          {dashboardStats.map(stat => (
            <div key={stat.id} className="bg-white p-5 rounded-lg shadow-sm flex items-center">
              <div className={`w-12 h-12 rounded-full ${stat.color} flex items-center justify-center mr-4`}>
                <stat.icon size={24} />
              </div>
              <div>
                <h3 className="text-2xl font-bold text-dark-700">{stat.value}</h3>
                <p className="text-gray-500 text-sm">{stat.label}</p>
              </div>
            </div>
          ))}
        </div>
        
        {/* Search and filter */}
        <div className="mb-8">
          <div className="relative">
            <input
              type="text"
              placeholder="Search your courses..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="input pl-10"
            />
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
          </div>
        </div>
        
        {/* Enrolled Courses */}
        <div className="mb-10">
          <h2 className="text-xl font-semibold text-dark-700 mb-4">Your Enrolled Courses</h2>
          {filteredCourses.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {filteredCourses.map((course) => (
                <CourseCard key={course.id} {...course} />
              ))}
            </div>
          ) : (
            <div className="bg-gray-50 rounded-lg p-8 text-center">
              <p className="text-gray-600">No courses found matching your search.</p>
            </div>
          )}
        </div>
        
        {/* Recent Activity */}
        <div>
          <h2 className="text-xl font-semibold text-dark-700 mb-4">Recent Activity</h2>
          <div className="bg-white rounded-lg shadow-sm divide-y">
            {recentActivities.map((activity) => (
              <motion.div
                key={activity.id}
                whileHover={{ backgroundColor: '#f9fafb' }}
                className="p-4 flex items-start cursor-pointer"
              >
                <div className={`mt-1 p-2 rounded-md ${
                  activity.type === 'video' ? 'bg-red-100 text-red-600' : 'bg-blue-100 text-blue-600'
                } mr-4`}>
                  {activity.type === 'video' ? <Video size={16} /> : <BookOpen size={16} />}
                </div>
                <div className="flex-1">
                  <h4 className="font-medium text-dark-700">{activity.title}</h4>
                  <p className="text-sm text-gray-500">{activity.course}</p>
                </div>
                <div className="text-xs text-gray-400">{activity.date}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default StudentDashboard;