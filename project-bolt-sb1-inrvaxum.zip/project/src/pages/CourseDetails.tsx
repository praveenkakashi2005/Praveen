import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import { motion } from 'framer-motion';
import { BookOpen, Clock, Calendar, User, Star, PlayCircle } from 'lucide-react';
import ReactPlayer from 'react-player';
import { videoPlayerConfig } from '../config/constants';

// Mock data for course details
const courseData = {
  '1': {
    id: '1',
    title: 'Introduction to Computer Science',
    description: 'This course provides a comprehensive introduction to computer science, covering fundamental concepts, programming basics, algorithms, and problem-solving skills. Students will learn the building blocks of computing systems and gain a solid foundation for advanced studies.',
    instructor: 'Prof. Alan Turing',
    duration: '8 weeks',
    startDate: '2023-02-01',
    rating: 4.8,
    enrolledStudents: 154,
    thumbnail: 'https://images.pexels.com/photos/546819/pexels-photo-546819.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    videoUrl: 'https://www.youtube.com/watch?v=jS4aFq5-91M',
    sections: [
      {
        id: 's1',
        title: 'Getting Started with Computer Science',
        lectures: [
          { id: 'l1', title: 'Introduction to the Course', duration: '10:25', type: 'video' },
          { id: 'l2', title: 'History of Computing', duration: '15:40', type: 'video' },
          { id: 'l3', title: 'Computing Systems Overview', duration: '12:15', type: 'video' },
          { id: 'l4', title: 'Week 1 Reading Materials', type: 'document' }
        ]
      },
      {
        id: 's2',
        title: 'Programming Fundamentals',
        lectures: [
          { id: 'l5', title: 'Variables and Data Types', duration: '14:30', type: 'video' },
          { id: 'l6', title: 'Control Structures', duration: '16:55', type: 'video' },
          { id: 'l7', title: 'Functions and Modules', duration: '18:20', type: 'video' },
          { id: 'l8', title: 'Week 2 Assignment', type: 'document' }
        ]
      },
      {
        id: 's3',
        title: 'Data Structures',
        lectures: [
          { id: 'l9', title: 'Arrays and Lists', duration: '13:45', type: 'video' },
          { id: 'l10', title: 'Stacks and Queues', duration: '15:10', type: 'video' },
          { id: 'l11', title: 'Week 3 Practice Problems', type: 'document' }
        ]
      }
    ]
  },
  '101': {
    id: '101',
    title: 'Introduction to Digital Marketing',
    description: 'This course provides a comprehensive introduction to digital marketing strategies and implementation. You will learn about various digital channels, content marketing, SEO, social media marketing, email campaigns, and analytics. By the end of this course, you will be able to create and implement effective digital marketing strategies.',
    instructor: 'Prof. Sarah Johnson',
    duration: '5 weeks',
    startDate: '2023-03-15',
    rating: 4.7,
    enrolledStudents: 128,
    thumbnail: 'https://images.pexels.com/photos/905163/pexels-photo-905163.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    videoUrl: 'https://www.youtube.com/watch?v=jS4aFq5-91M',
    sections: [
      {
        id: 's1',
        title: 'Digital Marketing Fundamentals',
        lectures: [
          { id: 'l1', title: 'Introduction to Digital Marketing', duration: '12:25', type: 'video' },
          { id: 'l2', title: 'Digital Marketing Channels Overview', duration: '14:40', type: 'video' },
          { id: 'l3', title: 'Building a Digital Marketing Strategy', duration: '16:35', type: 'video' },
          { id: 'l4', title: 'Week 1 Reading Materials', type: 'document' }
        ]
      },
      {
        id: 's2',
        title: 'Content Marketing and SEO',
        lectures: [
          { id: 'l5', title: 'Content Marketing Principles', duration: '15:20', type: 'video' },
          { id: 'l6', title: 'SEO Fundamentals', duration: '18:15', type: 'video' },
          { id: 'l7', title: 'Creating SEO-Optimized Content', duration: '14:50', type: 'video' },
          { id: 'l8', title: 'Week 2 Assignment', type: 'document' }
        ]
      },
      {
        id: 's3',
        title: 'Social Media Marketing',
        lectures: [
          { id: 'l9', title: 'Social Media Platforms Overview', duration: '13:40', type: 'video' },
          { id: 'l10', title: 'Building a Social Media Strategy', duration: '17:25', type: 'video' },
          { id: 'l11', title: 'Week 3 Case Study', type: 'document' }
        ]
      }
    ]
  }
};

const CourseDetails: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [currentLecture, setCurrentLecture] = useState<string | null>(null);
  const [expandedSections, setExpandedSections] = useState<string[]>([]);
  
  // Handle missing course ID or non-existent course
  if (!id || !courseData[id]) {
    return (
      <div className="pt-20 pb-10 min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-700 mb-2">Course Not Found</h2>
          <p className="text-gray-500">The course you're looking for doesn't exist or has been removed.</p>
        </div>
      </div>
    );
  }
  
  const course = courseData[id];
  
  // Toggle section expansion
  const toggleSection = (sectionId: string) => {
    if (expandedSections.includes(sectionId)) {
      setExpandedSections(expandedSections.filter(id => id !== sectionId));
    } else {
      setExpandedSections([...expandedSections, sectionId]);
    }
  };
  
  // Handle lecture selection
  const handleLectureClick = (lectureId: string) => {
    setCurrentLecture(lectureId);
  };
  
  return (
    <div className="pt-20 pb-10">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2">
            {/* Video Player */}
            <div className="bg-dark-900 rounded-lg overflow-hidden shadow-lg mb-6">
              {currentLecture ? (
                <ReactPlayer
                  url={course.videoUrl}
                  {...videoPlayerConfig}
                  width="100%"
                  height="480px"
                />
              ) : (
                <div 
                  className="relative h-[480px] bg-gradient-to-br from-gray-800 to-dark-900 flex items-center justify-center"
                  style={{ 
                    backgroundImage: `linear-gradient(rgba(0,0,0,0.7), rgba(0,0,0,0.7)), url(${course.thumbnail})`,
                    backgroundSize: 'cover',
                    backgroundPosition: 'center'
                  }}
                >
                  <div className="text-center text-white p-6">
                    <PlayCircle size={64} className="mx-auto mb-4 text-secondary-400" />
                    <h3 className="text-2xl font-bold mb-2">{course.title}</h3>
                    <p className="opacity-80">Click on a lecture to start learning</p>
                  </div>
                </div>
              )}
            </div>
            
            {/* Course Info */}
            <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
              <h1 className="text-2xl font-bold text-dark-700 mb-3">{course.title}</h1>
              
              <div className="flex flex-wrap gap-4 text-sm text-gray-600 mb-4">
                <div className="flex items-center">
                  <User size={16} className="mr-1 text-primary-500" />
                  <span>{course.instructor}</span>
                </div>
                <div className="flex items-center">
                  <Clock size={16} className="mr-1 text-primary-500" />
                  <span>{course.duration}</span>
                </div>
                <div className="flex items-center">
                  <Calendar size={16} className="mr-1 text-primary-500" />
                  <span>Started {new Date(course.startDate).toLocaleDateString()}</span>
                </div>
                <div className="flex items-center">
                  <Star size={16} className="mr-1 text-secondary-500" />
                  <span>{course.rating} rating</span>
                </div>
              </div>
              
              <div className="border-t border-gray-100 pt-4">
                <h3 className="font-medium text-dark-700 mb-3">About This Course</h3>
                <p className="text-gray-600 leading-relaxed">
                  {course.description}
                </p>
              </div>
            </div>
          </div>
          
          {/* Course Content Sidebar */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow-sm overflow-hidden">
              <div className="p-4 bg-primary-50 border-b border-primary-100">
                <h3 className="font-medium text-dark-700 flex items-center">
                  <BookOpen size={18} className="mr-2 text-primary-500" />
                  Course Content
                </h3>
                <div className="text-sm text-gray-500 mt-1">
                  {course.sections.reduce((total, section) => total + section.lectures.length, 0)} lectures • {course.duration}
                </div>
              </div>
              
              <div className="divide-y">
                {course.sections.map((section) => (
                  <div key={section.id} className="overflow-hidden">
                    {/* Section Header */}
                    <button 
                      onClick={() => toggleSection(section.id)}
                      className="w-full p-4 text-left flex items-center justify-between hover:bg-gray-50"
                    >
                      <h4 className="font-medium text-dark-700">{section.title}</h4>
                      <span className="transform transition-transform duration-200">
                        {expandedSections.includes(section.id) ? '−' : '+'}
                      </span>
                    </button>
                    
                    {/* Section Content */}
                    {expandedSections.includes(section.id) && (
                      <motion.div
                        initial={{ height: 0 }}
                        animate={{ height: 'auto' }}
                        exit={{ height: 0 }}
                        transition={{ duration: 0.2 }}
                        className="bg-gray-50"
                      >
                        {section.lectures.map((lecture) => (
                          <button
                            key={lecture.id}
                            onClick={() => handleLectureClick(lecture.id)}
                            className={`w-full p-3 pl-8 text-left flex items-start hover:bg-gray-100 ${
                              currentLecture === lecture.id ? 'bg-primary-50' : ''
                            }`}
                          >
                            <div className="mr-3 mt-0.5">
                              {lecture.type === 'video' ? (
                                <PlayCircle size={16} className="text-primary-500" />
                              ) : (
                                <FileText size={16} className="text-secondary-500" />
                              )}
                            </div>
                            <div className="flex-1 text-sm">
                              <div className="font-medium text-dark-700">{lecture.title}</div>
                              {lecture.duration && (
                                <div className="text-xs text-gray-500 mt-1">{lecture.duration}</div>
                              )}
                            </div>
                          </button>
                        ))}
                      </motion.div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CourseDetails;