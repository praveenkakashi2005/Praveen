import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Search, Filter } from 'lucide-react';
import CourseCard from '../components/CourseCard';

// Mock data - would be fetched from API in a real app
const commonCourses = [
  {
    id: '101',
    title: 'Introduction to Digital Marketing',
    description: 'Learn the fundamentals of digital marketing strategies and implementation',
    instructor: 'Prof. Sarah Johnson',
    duration: '5 weeks',
    thumbnail: 'https://images.pexels.com/photos/905163/pexels-photo-905163.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
  },
  {
    id: '102',
    title: 'Business Communication Skills',
    description: 'Master effective communication techniques for professional success',
    instructor: 'Dr. Michael Chen',
    duration: '4 weeks',
    thumbnail: 'https://images.pexels.com/photos/3184360/pexels-photo-3184360.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
  },
  {
    id: '103',
    title: 'Personal Finance Management',
    description: 'Essential financial literacy skills for college students and young professionals',
    instructor: 'Prof. Emily Rodriguez',
    duration: '6 weeks',
    thumbnail: 'https://images.pexels.com/photos/534216/pexels-photo-534216.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
  },
  {
    id: '104',
    title: 'Entrepreneurship Fundamentals',
    description: 'Learn how to develop business ideas and build successful startups',
    instructor: 'Dr. James Wilson',
    duration: '8 weeks',
    thumbnail: 'https://images.pexels.com/photos/4065864/pexels-photo-4065864.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
  },
  {
    id: '105',
    title: 'Public Speaking and Presentation',
    description: 'Develop confident public speaking and presentation skills',
    instructor: 'Prof. Lisa Taylor',
    duration: '5 weeks',
    thumbnail: 'https://images.pexels.com/photos/2173508/pexels-photo-2173508.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
  },
  {
    id: '106',
    title: 'Critical Thinking and Problem Solving',
    description: 'Enhance your analytical thinking and problem-solving abilities',
    instructor: 'Dr. Robert Garcia',
    duration: '6 weeks',
    thumbnail: 'https://images.pexels.com/photos/3184292/pexels-photo-3184292.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
  }
];

const CommonCourses: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [showFilters, setShowFilters] = useState(false);
  
  // Filter courses based on search term
  const filteredCourses = commonCourses.filter(course => 
    course.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    course.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
    course.instructor.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="pt-20 pb-10">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="bg-gradient-to-r from-secondary-500 to-secondary-700 text-white rounded-lg p-6 mb-8 shadow-md">
          <h1 className="text-2xl font-bold mb-2">Common Courses</h1>
          <p className="opacity-90">Explore additional courses available to all students</p>
        </div>
        
        {/* Search and Filters */}
        <div className="mb-8">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-grow">
              <input
                type="text"
                placeholder="Search courses..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="input pl-10"
              />
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
            </div>
            
            <button
              onClick={() => setShowFilters(!showFilters)}
              className="md:w-auto w-full btn bg-gray-100 text-gray-700 hover:bg-gray-200 flex items-center justify-center"
            >
              <Filter size={18} className="mr-2" />
              Filters
            </button>
          </div>
          
          {/* Filters Panel */}
          {showFilters && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="bg-white rounded-lg shadow-sm mt-4 p-4 overflow-hidden"
            >
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Duration
                  </label>
                  <select className="input">
                    <option value="">Any Duration</option>
                    <option value="short">Short (1-4 weeks)</option>
                    <option value="medium">Medium (5-8 weeks)</option>
                    <option value="long">Long (9+ weeks)</option>
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Category
                  </label>
                  <select className="input">
                    <option value="">All Categories</option>
                    <option value="business">Business</option>
                    <option value="technology">Technology</option>
                    <option value="communication">Communication</option>
                    <option value="personal">Personal Development</option>
                  </select>
                </div>
                
                <div className="flex items-end">
                  <button className="btn btn-primary w-full">
                    Apply Filters
                  </button>
                </div>
              </div>
            </motion.div>
          )}
        </div>
        
        {/* Course Grid */}
        {filteredCourses.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredCourses.map((course) => (
              <CourseCard key={course.id} {...course} />
            ))}
          </div>
        ) : (
          <div className="bg-white rounded-lg shadow-sm p-8 text-center">
            <h3 className="text-lg font-medium text-gray-700 mb-2">No courses found</h3>
            <p className="text-gray-500">
              Try adjusting your search or filters to find what you're looking for.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default CommonCourses;