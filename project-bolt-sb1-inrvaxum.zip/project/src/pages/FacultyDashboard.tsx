import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { UploadCloud, Film, FileText, BookOpen, Trash2, Eye, Search, Plus } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

// Mock data - would be fetched from API in a real app
const mockLectures = [
  {
    id: '1',
    title: 'Introduction to Programming Concepts',
    description: 'Fundamental programming concepts and their applications',
    date: '2023-01-15',
    type: 'video',
    views: 128,
    thumbnail: 'https://images.pexels.com/photos/574071/pexels-photo-574071.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
  },
  {
    id: '2',
    title: 'Data Types and Variables',
    description: 'Understanding different data types and variable usage',
    date: '2023-01-22',
    type: 'video',
    views: 95,
    thumbnail: 'https://images.pexels.com/photos/4164418/pexels-photo-4164418.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
  },
  {
    id: '3',
    title: 'Algorithm Design Patterns',
    description: 'Common algorithm design patterns and their implementations',
    date: '2023-02-01',
    type: 'document',
    views: 76,
    thumbnail: 'https://images.pexels.com/photos/590022/pexels-photo-590022.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
  },
  {
    id: '4',
    title: 'Control Structures',
    description: 'If statements, loops, and conditional logic',
    date: '2023-02-08',
    type: 'video',
    views: 64,
    thumbnail: 'https://images.pexels.com/photos/577585/pexels-photo-577585.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
  }
];

const FacultyDashboard: React.FC = () => {
  const { user } = useAuth();
  const [searchTerm, setSearchTerm] = useState('');
  const [activeTab, setActiveTab] = useState<'all' | 'videos' | 'documents'>('all');
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);
  const [uploadType, setUploadType] = useState<'video' | 'document'>('video');
  
  // Filter lectures based on search term and active tab
  const filteredLectures = mockLectures.filter(lecture => {
    const matchesSearch = 
      lecture.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      lecture.description.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesType = 
      activeTab === 'all' || 
      (activeTab === 'videos' && lecture.type === 'video') ||
      (activeTab === 'documents' && lecture.type === 'document');
    
    return matchesSearch && matchesType;
  });

  return (
    <div className="pt-20 pb-10">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="bg-gradient-to-r from-primary-700 to-primary-800 text-white rounded-lg p-6 mb-8 shadow-md">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between">
            <div>
              <h1 className="text-2xl font-bold mb-2">Faculty Dashboard</h1>
              <p className="opacity-90">Welcome back, Professor {user?.name}</p>
            </div>
            <button 
              onClick={() => setIsUploadModalOpen(true)}
              className="mt-4 md:mt-0 btn bg-white text-primary-700 hover:bg-gray-100 flex items-center"
            >
              <UploadCloud size={18} className="mr-2" />
              Upload Content
            </button>
          </div>
        </div>
        
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          <div className="bg-white p-5 rounded-lg shadow-sm">
            <div className="flex items-center">
              <div className="w-12 h-12 rounded-full bg-primary-100 text-primary-600 flex items-center justify-center mr-4">
                <Film size={24} />
              </div>
              <div>
                <h3 className="text-2xl font-bold text-dark-700">12</h3>
                <p className="text-gray-500 text-sm">Videos Uploaded</p>
              </div>
            </div>
          </div>
          
          <div className="bg-white p-5 rounded-lg shadow-sm">
            <div className="flex items-center">
              <div className="w-12 h-12 rounded-full bg-secondary-100 text-secondary-600 flex items-center justify-center mr-4">
                <FileText size={24} />
              </div>
              <div>
                <h3 className="text-2xl font-bold text-dark-700">8</h3>
                <p className="text-gray-500 text-sm">Documents Shared</p>
              </div>
            </div>
          </div>
          
          <div className="bg-white p-5 rounded-lg shadow-sm">
            <div className="flex items-center">
              <div className="w-12 h-12 rounded-full bg-green-100 text-green-600 flex items-center justify-center mr-4">
                <Eye size={24} />
              </div>
              <div>
                <h3 className="text-2xl font-bold text-dark-700">425</h3>
                <p className="text-gray-500 text-sm">Total Views</p>
              </div>
            </div>
          </div>
        </div>
        
        {/* Search and Filters */}
        <div className="mb-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="relative flex-grow max-w-md">
              <input
                type="text"
                placeholder="Search your uploads..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="input pl-10"
              />
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
            </div>
            
            <div className="flex space-x-2">
              <button 
                onClick={() => setActiveTab('all')}
                className={`btn ${
                  activeTab === 'all' 
                    ? 'bg-primary-600 text-white' 
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                All
              </button>
              <button 
                onClick={() => setActiveTab('videos')}
                className={`btn flex items-center ${
                  activeTab === 'videos' 
                    ? 'bg-primary-600 text-white' 
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                <Film size={16} className="mr-2" />
                Videos
              </button>
              <button 
                onClick={() => setActiveTab('documents')}
                className={`btn flex items-center ${
                  activeTab === 'documents' 
                    ? 'bg-primary-600 text-white' 
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                <FileText size={16} className="mr-2" />
                Documents
              </button>
            </div>
          </div>
        </div>
        
        {/* Content Grid */}
        <div className="bg-white rounded-lg shadow-sm overflow-hidden">
          {filteredLectures.length > 0 ? (
            <div className="divide-y">
              {filteredLectures.map((lecture) => (
                <motion.div
                  key={lecture.id}
                  whileHover={{ backgroundColor: '#f9fafb' }}
                  className="p-4 sm:p-6 flex flex-col sm:flex-row items-start gap-4"
                >
                  {/* Thumbnail */}
                  <div className="w-full sm:w-40 h-24 rounded-md overflow-hidden flex-shrink-0 bg-gray-100">
                    {lecture.thumbnail && (
                      <img 
                        src={lecture.thumbnail} 
                        alt={lecture.title} 
                        className="w-full h-full object-cover"
                      />
                    )}
                  </div>
                  
                  {/* Content */}
                  <div className="flex-grow">
                    <div className="flex items-start justify-between">
                      <div>
                        <h3 className="font-medium text-dark-700">{lecture.title}</h3>
                        <p className="text-sm text-gray-500 mt-1">{lecture.description}</p>
                        <div className="flex items-center mt-2 text-xs text-gray-500">
                          <span className="flex items-center">
                            {lecture.type === 'video' ? (
                              <Film size={14} className="mr-1 text-primary-500" />
                            ) : (
                              <FileText size={14} className="mr-1 text-secondary-500" />
                            )}
                            {lecture.type === 'video' ? 'Video' : 'Document'}
                          </span>
                          <span className="mx-2">•</span>
                          <span>{new Date(lecture.date).toLocaleDateString()}</span>
                          <span className="mx-2">•</span>
                          <span className="flex items-center">
                            <Eye size={14} className="mr-1" />
                            {lecture.views} views
                          </span>
                        </div>
                      </div>
                      
                      {/* Actions */}
                      <div className="flex space-x-2">
                        <button className="p-2 text-gray-500 hover:text-dark-700 hover:bg-gray-100 rounded-full transition-colors">
                          <Eye size={16} />
                        </button>
                        <button className="p-2 text-gray-500 hover:text-red-600 hover:bg-red-50 rounded-full transition-colors">
                          <Trash2 size={16} />
                        </button>
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          ) : (
            <div className="p-8 text-center">
              <BookOpen size={48} className="mx-auto text-gray-300 mb-4" />
              <h3 className="text-lg font-medium text-gray-700 mb-1">No content found</h3>
              <p className="text-gray-500 mb-4">
                {searchTerm 
                  ? 'No results match your search criteria' 
                  : 'You haven\'t uploaded any content yet'}
              </p>
              <button 
                onClick={() => setIsUploadModalOpen(true)}
                className="btn btn-primary inline-flex items-center"
              >
                <Plus size={16} className="mr-2" />
                Upload Now
              </button>
            </div>
          )}
        </div>
        
        {/* Upload Modal */}
        {isUploadModalOpen && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="bg-white rounded-lg shadow-xl max-w-lg w-full mx-auto p-6"
            >
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold text-dark-700">Upload Content</h2>
                <button 
                  onClick={() => setIsUploadModalOpen(false)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <X size={20} />
                </button>
              </div>
              
              {/* Upload Type Selector */}
              <div className="flex space-x-4 mb-6">
                <button
                  onClick={() => setUploadType('video')}
                  className={`flex-1 py-3 rounded-md flex flex-col items-center justify-center border-2 transition-colors ${
                    uploadType === 'video'
                      ? 'border-primary-500 bg-primary-50 text-primary-600'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <Film size={24} className={uploadType === 'video' ? 'text-primary-500' : 'text-gray-500'} />
                  <span className="mt-2 font-medium">Video</span>
                </button>
                
                <button
                  onClick={() => setUploadType('document')}
                  className={`flex-1 py-3 rounded-md flex flex-col items-center justify-center border-2 transition-colors ${
                    uploadType === 'document'
                      ? 'border-primary-500 bg-primary-50 text-primary-600'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <FileText size={24} className={uploadType === 'document' ? 'text-primary-500' : 'text-gray-500'} />
                  <span className="mt-2 font-medium">Document</span>
                </button>
              </div>
              
              {/* Form Fields */}
              <form className="space-y-4">
                <div>
                  <label htmlFor="title" className="block text-sm font-medium text-gray-700 mb-1">
                    Title
                  </label>
                  <input
                    id="title"
                    type="text"
                    className="input"
                    placeholder="Enter content title"
                  />
                </div>
                
                <div>
                  <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-1">
                    Description
                  </label>
                  <textarea
                    id="description"
                    rows={3}
                    className="input"
                    placeholder="Enter content description"
                  ></textarea>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    {uploadType === 'video' ? 'Video' : 'Document'} File
                  </label>
                  <div className="border-2 border-dashed border-gray-300 rounded-md p-6 text-center hover:border-primary-500 transition-colors">
                    <input
                      type="file"
                      className="hidden"
                      id="file-upload"
                      accept={uploadType === 'video' ? 'video/*' : '.pdf,.doc,.docx,.ppt,.pptx'}
                    />
                    <label 
                      htmlFor="file-upload"
                      className="cursor-pointer flex flex-col items-center"
                    >
                      <UploadCloud size={36} className="text-gray-400 mb-2" />
                      <p className="text-sm text-gray-500">
                        Drag and drop your {uploadType}, or <span className="text-primary-600 font-medium">browse</span>
                      </p>
                      <p className="text-xs text-gray-400 mt-1">
                        {uploadType === 'video' 
                          ? 'MP4, WebM or OGG (max 100MB)' 
                          : 'PDF, DOC, DOCX, PPT or PPTX (max 20MB)'}
                      </p>
                    </label>
                  </div>
                </div>
                
                <div className="flex justify-end space-x-3 pt-4">
                  <button
                    type="button"
                    onClick={() => setIsUploadModalOpen(false)}
                    className="btn bg-gray-100 text-gray-700 hover:bg-gray-200"
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    className="btn btn-primary"
                  >
                    Upload
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </div>
    </div>
  );
};

export default FacultyDashboard;