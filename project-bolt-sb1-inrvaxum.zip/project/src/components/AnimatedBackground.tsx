import React, { useCallback } from 'react';
import { motion } from 'framer-motion';

interface AnimatedBackgroundProps {
  children: React.ReactNode;
  intensity?: 'low' | 'medium' | 'high';
}

const AnimatedBackground: React.FC<AnimatedBackgroundProps> = ({ 
  children, 
  intensity = 'medium' 
}) => {
  // Calculate animation speed based on intensity
  const getAnimationDuration = useCallback(() => {
    switch (intensity) {
      case 'low': return 25;
      case 'high': return 15;
      case 'medium':
      default: return 20;
    }
  }, [intensity]);

  return (
    <div className="relative overflow-hidden min-h-screen">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-dark-800 via-primary-900 to-dark-900 opacity-90 z-0"></div>
      
      {/* Animated wave elements */}
      <div className="absolute inset-0 z-0">
        <motion.div
          className="absolute bottom-0 left-0 w-[200%] h-64"
          style={{
            background: 'linear-gradient(90deg, transparent, rgba(59, 100, 246, 0.1))',
            maskImage: 'url("data:image/svg+xml,%3Csvg width=\'100%25\' height=\'100%25\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Cpath d=\'M0,50 C150,150 350,0 500,50 L500,0 L0,0 Z\' fill=\'%23fff\'/%3E%3C/svg%3E")',
            maskSize: '100% 100%',
          }}
          animate={{
            x: [0, '-50%'],
          }}
          transition={{
            x: {
              repeat: Infinity,
              repeatType: 'loop',
              duration: getAnimationDuration(),
              ease: 'linear',
            },
          }}
        />
        
        <motion.div
          className="absolute bottom-0 left-0 w-[200%] h-48"
          style={{
            background: 'linear-gradient(90deg, transparent, rgba(218, 142, 27, 0.15))',
            maskImage: 'url("data:image/svg+xml,%3Csvg width=\'100%25\' height=\'100%25\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Cpath d=\'M0,100 C300,0 400,100 500,50 L500,0 L0,0 Z\' fill=\'%23fff\'/%3E%3C/svg%3E")',
            maskSize: '100% 100%',
          }}
          animate={{
            x: ['-50%', '0%'],
          }}
          transition={{
            x: {
              repeat: Infinity,
              repeatType: 'loop',
              duration: getAnimationDuration() * 0.8,
              ease: 'linear',
            },
          }}
        />
        
        <motion.div
          className="absolute top-0 right-0 w-[200%] h-96"
          style={{
            background: 'linear-gradient(90deg, rgba(218, 142, 27, 0.1), transparent)',
            maskImage: 'url("data:image/svg+xml,%3Csvg width=\'100%25\' height=\'100%25\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Cpath d=\'M0,0 C150,120 350,50 500,100 L500,0 L0,0 Z\' fill=\'%23fff\'/%3E%3C/svg%3E")',
            maskSize: '100% 100%',
          }}
          animate={{
            x: ['0%', '-50%'],
          }}
          transition={{
            x: {
              repeat: Infinity,
              repeatType: 'loop',
              duration: getAnimationDuration() * 1.2,
              ease: 'linear',
            },
          }}
        />
      </div>
      
      {/* Floating particles */}
      <div className="absolute inset-0 z-0">
        {[...Array(6)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute rounded-full bg-white bg-opacity-20"
            style={{
              width: Math.random() * 20 + 5,
              height: Math.random() * 20 + 5,
              top: `${Math.random() * 100}%`,
              left: `${Math.random() * 100}%`,
            }}
            animate={{
              y: [0, -30, 0],
              opacity: [0.1, 0.3, 0.1],
            }}
            transition={{
              y: {
                repeat: Infinity,
                duration: Math.random() * 5 + 3,
                ease: 'easeInOut',
              },
              opacity: {
                repeat: Infinity,
                duration: Math.random() * 5 + 3,
                ease: 'easeInOut',
              },
            }}
          />
        ))}
      </div>
      
      {/* Content */}
      <div className="relative z-10">
        {children}
      </div>
    </div>
  );
};

export default AnimatedBackground;