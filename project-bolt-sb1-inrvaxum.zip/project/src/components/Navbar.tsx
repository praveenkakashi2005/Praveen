import React, { useState, useEffect } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { Menu, X, BookOpen, LogOut, User } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

const Navbar: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const { user, logout } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const [scrolled, setScrolled] = useState(false);

  // Check if current path is homepage
  const isHomePage = location.pathname === '/';

  // Handle scroll event for transparent navbar
  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 20) {
        setScrolled(true);
      } else {
        setScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleMenu = () => {
    setIsOpen(!isOpen);
  };

  const handleLogout = () => {
    logout();
    navigate('/');
    setIsOpen(false);
  };

  // Determine navigation items based on user role
  const getNavItems = () => {
    const items = [
      { label: 'Home', path: '/' },
      { label: 'Common Courses', path: '/common-courses' },
    ];

    if (user) {
      if (user.role === 'student') {
        items.push({ label: 'My Dashboard', path: '/student-dashboard' });
      } else if (user.role === 'faculty') {
        items.push({ label: 'Faculty Dashboard', path: '/faculty-dashboard' });
      }
    } else {
      items.push(
        { label: 'Login', path: '/login' },
        { label: 'Register', path: '/register' }
      );
    }

    return items;
  };

  const navItems = getNavItems();

  return (
    <nav 
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled || !isHomePage 
          ? 'bg-white shadow-md py-2' 
          : 'bg-transparent py-4'
      }`}
    >
      <div className="container mx-auto px-4 md:px-6">
        <div className="flex justify-between items-center">
          {/* Logo */}
          <Link 
            to="/" 
            className="flex items-center space-x-2"
          >
            <BookOpen 
              size={28} 
              className={`${scrolled || !isHomePage ? 'text-primary-600' : 'text-white'}`} 
            />
            <span 
              className={`text-xl font-bold ${
                scrolled || !isHomePage ? 'text-dark-700' : 'text-white'
              }`}
            >
              Sona Learn
            </span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            {navItems.map((item) => (
              <Link
                key={item.path}
                to={item.path}
                className={`font-medium transition-colors ${
                  location.pathname === item.path
                    ? 'text-primary-600'
                    : scrolled || !isHomePage
                    ? 'text-dark-600 hover:text-primary-600'
                    : 'text-white hover:text-secondary-300'
                }`}
              >
                {item.label}
              </Link>
            ))}
            
            {/* User menu if logged in */}
            {user && (
              <div className="relative group">
                <button 
                  className={`flex items-center space-x-1 font-medium ${
                    scrolled || !isHomePage ? 'text-dark-600' : 'text-white'
                  }`}
                >
                  <User size={18} />
                  <span className="max-w-[100px] truncate">{user.name}</span>
                </button>
                <div className="absolute right-0 mt-2 w-48 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 hidden group-hover:block">
                  <div className="py-1">
                    <button
                      onClick={handleLogout}
                      className="w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 flex items-center"
                    >
                      <LogOut size={16} className="mr-2" />
                      Logout
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Mobile menu button */}
          <button
            onClick={toggleMenu}
            className="md:hidden text-gray-600 focus:outline-none"
          >
            {isOpen ? (
              <X 
                size={24} 
                className={scrolled || !isHomePage ? 'text-dark-700' : 'text-white'} 
              />
            ) : (
              <Menu 
                size={24} 
                className={scrolled || !isHomePage ? 'text-dark-700' : 'text-white'} 
              />
            )}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isOpen && (
          <div className="md:hidden mt-4 pb-4">
            <div className="flex flex-col space-y-3">
              {navItems.map((item) => (
                <Link
                  key={item.path}
                  to={item.path}
                  className={`font-medium py-2 ${
                    location.pathname === item.path
                      ? 'text-primary-600'
                      : 'text-dark-600'
                  }`}
                  onClick={() => setIsOpen(false)}
                >
                  {item.label}
                </Link>
              ))}
              
              {/* User options */}
              {user && (
                <button
                  onClick={handleLogout}
                  className="flex items-center space-x-2 text-red-600 py-2"
                >
                  <LogOut size={18} />
                  <span>Logout</span>
                </button>
              )}
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navbar;