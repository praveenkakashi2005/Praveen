import React from 'react';
import { Link } from 'react-router-dom';
import { BookOpen, Clock, User } from 'lucide-react';
import { motion } from 'framer-motion';

interface CourseCardProps {
  id: string;
  title: string;
  description: string;
  instructor: string;
  duration: string;
  thumbnail?: string;
}

const CourseCard: React.FC<CourseCardProps> = ({
  id,
  title,
  description,
  instructor,
  duration,
  thumbnail = 'https://images.pexels.com/photos/4144923/pexels-photo-4144923.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
}) => {
  return (
    <motion.div
      whileHover={{ y: -5 }}
      className="card overflow-hidden transition-all duration-300 h-full flex flex-col"
    >
      <div className="relative h-48 overflow-hidden">
        <img
          src={thumbnail}
          alt={title}
          className="w-full h-full object-cover transition-transform duration-500 hover:scale-110"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-dark-800 to-transparent opacity-60"></div>
      </div>
      
      <div className="p-5 flex-grow flex flex-col">
        <h3 className="text-lg font-semibold text-dark-700 mb-2 line-clamp-2">{title}</h3>
        
        <p className="text-gray-600 text-sm mb-4 line-clamp-2">
          {description}
        </p>
        
        <div className="mt-auto space-y-2">
          <div className="flex items-center text-sm text-gray-500">
            <User size={16} className="mr-2 text-primary-500" />
            <span>{instructor}</span>
          </div>
          
          <div className="flex items-center text-sm text-gray-500">
            <Clock size={16} className="mr-2 text-primary-500" />
            <span>{duration}</span>
          </div>
        </div>
        
        <Link
          to={`/course/${id}`}
          className="mt-4 btn btn-primary w-full flex items-center justify-center"
        >
          <BookOpen size={16} className="mr-2" />
          View Course
        </Link>
      </div>
    </motion.div>
  );
};

export default CourseCard;