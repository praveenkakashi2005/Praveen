/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        primary: {
          50: '#eef4ff',
          100: '#d9e5ff',
          200: '#bcd1ff',
          300: '#91b4fe',
          400: '#608cfb',
          500: '#3b64f6',
          600: '#2546ec',
          700: '#1c36db',
          800: '#1e30b2',
          900: '#1f318c',
          950: '#151d54',
        },
        secondary: {
          50: '#fbf6e8',
          100: '#f6eaca',
          200: '#efd69a',
          300: '#e7bd61',
          400: '#e0a635',
          500: '#da8e1b',
          600: '#c77013',
          700: '#a45213',
          800: '#864118',
          900: '#703619',
          950: '#3f1a0c',
        },
        dark: {
          100: '#d5d7e0',
          200: '#acafbf',
          300: '#82879f',
          400: '#595f7e',
          500: '#2f375e',
          600: '#252c4b',
          700: '#1c2138',
          800: '#121626',
          900: '#090b13',
        }
      },
      animation: {
        'wave': 'wave 15s linear infinite',
        'pulse-slow': 'pulse 4s cubic-bezier(0.4, 0, 0.6, 1) infinite',
      },
      keyframes: {
        wave: {
          '0%': { transform: 'translateX(0) translateZ(0) scaleY(1)' },
          '50%': { transform: 'translateX(-25%) translateZ(0) scaleY(0.8)' },
          '100%': { transform: 'translateX(-50%) translateZ(0) scaleY(1)' },
        }
      },
    },
  },
  plugins: [],
};