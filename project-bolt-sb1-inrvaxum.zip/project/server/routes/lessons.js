import express from 'express';
import asyncHandler from 'express-async-handler';
import multer from 'multer';
import Course from '../models/Course.js';
import { protect, faculty } from '../middleware/authMiddleware.js';

const router = express.Router();

// Configure multer storage
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'uploads/');
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1e9);
    cb(null, uniqueSuffix + '-' + file.originalname);
  },
});

const upload = multer({ storage: storage });

// @desc    Add a section to a course
// @route   POST /api/lessons/courses/:courseId/sections
// @access  Private/Faculty
router.post(
  '/courses/:courseId/sections',
  protect,
  faculty,
  asyncHandler(async (req, res) => {
    const { title } = req.body;
    
    const course = await Course.findById(req.params.courseId);
    
    if (course) {
      // Verify course belongs to faculty
      if (course.instructor.toString() !== req.user._id.toString()) {
        res.status(401);
        throw new Error('Not authorized to update this course');
      }
      
      const section = {
        title,
        lessons: [],
      };
      
      course.sections.push(section);
      await course.save();
      
      res.status(201).json(course);
    } else {
      res.status(404);
      throw new Error('Course not found');
    }
  })
);

// @desc    Add a lesson to a section
// @route   POST /api/lessons/courses/:courseId/sections/:sectionId
// @access  Private/Faculty
router.post(
  '/courses/:courseId/sections/:sectionId',
  protect,
  faculty,
  upload.single('file'),
  asyncHandler(async (req, res) => {
    const { title, description, contentType, duration, content } = req.body;
    
    const course = await Course.findById(req.params.courseId);
    
    if (course) {
      // Verify course belongs to faculty
      if (course.instructor.toString() !== req.user._id.toString()) {
        res.status(401);
        throw new Error('Not authorized to update this course');
      }
      
      // Find the section
      const section = course.sections.id(req.params.sectionId);
      
      if (section) {
        const lesson = {
          title,
          description,
          contentType,
          duration: duration || '',
          content,
          fileUrl: req.file ? req.file.path : '',
        };
        
        section.lessons.push(lesson);
        await course.save();
        
        res.status(201).json(course);
      } else {
        res.status(404);
        throw new Error('Section not found');
      }
    } else {
      res.status(404);
      throw new Error('Course not found');
    }
  })
);

// @desc    Delete a lesson
// @route   DELETE /api/lessons/courses/:courseId/sections/:sectionId/lessons/:lessonId
// @access  Private/Faculty
router.delete(
  '/courses/:courseId/sections/:sectionId/lessons/:lessonId',
  protect,
  faculty,
  asyncHandler(async (req, res) => {
    const course = await Course.findById(req.params.courseId);
    
    if (course) {
      // Verify course belongs to faculty
      if (course.instructor.toString() !== req.user._id.toString()) {
        res.status(401);
        throw new Error('Not authorized to update this course');
      }
      
      // Find the section
      const section = course.sections.id(req.params.sectionId);
      
      if (section) {
        // Find and remove the lesson
        const lessonIndex = section.lessons.findIndex(
          (l) => l._id.toString() === req.params.lessonId
        );
        
        if (lessonIndex !== -1) {
          section.lessons.splice(lessonIndex, 1);
          await course.save();
          
          res.json({ message: 'Lesson removed' });
        } else {
          res.status(404);
          throw new Error('Lesson not found');
        }
      } else {
        res.status(404);
        throw new Error('Section not found');
      }
    } else {
      res.status(404);
      throw new Error('Course not found');
    }
  })
);

export default router;