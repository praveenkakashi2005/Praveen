import express from 'express';
import asyncHandler from 'express-async-handler';
import multer from 'multer';
import Course from '../models/Course.js';
import { protect, faculty } from '../middleware/authMiddleware.js';

const router = express.Router();

// @desc    Get all courses
// @route   GET /api/courses
// @access  Public
router.get(
  '/',
  asyncHandler(async (req, res) => {
    const courses = await Course.find({}).populate('instructor', 'name');
    res.json(courses);
  })
);

// @desc    Get common courses
// @route   GET /api/courses/common
// @access  Public
router.get(
  '/common',
  asyncHandler(async (req, res) => {
    const courses = await Course.find({ isCommonCourse: true }).populate('instructor', 'name');
    res.json(courses);
  })
);

// @desc    Get course by ID
// @route   GET /api/courses/:id
// @access  Public
router.get(
  '/:id',
  asyncHandler(async (req, res) => {
    const course = await Course.findById(req.params.id).populate('instructor', 'name');
    
    if (course) {
      res.json(course);
    } else {
      res.status(404);
      throw new Error('Course not found');
    }
  })
);

// Configure multer storage
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'uploads/');
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1e9);
    cb(null, uniqueSuffix + '-' + file.originalname);
  },
});

const upload = multer({ storage: storage });

// @desc    Create a course
// @route   POST /api/courses
// @access  Private/Faculty
router.post(
  '/',
  protect,
  faculty,
  upload.single('thumbnail'),
  asyncHandler(async (req, res) => {
    const { title, description, duration, isCommonCourse } = req.body;
    
    const course = new Course({
      title,
      description,
      instructor: req.user._id,
      duration,
      isCommonCourse: isCommonCourse === 'true',
      thumbnail: req.file ? req.file.path : null,
      sections: [],
    });
    
    const createdCourse = await course.save();
    res.status(201).json(createdCourse);
  })
);

// @desc    Update a course
// @route   PUT /api/courses/:id
// @access  Private/Faculty
router.put(
  '/:id',
  protect,
  faculty,
  asyncHandler(async (req, res) => {
    const { title, description, duration, isCommonCourse } = req.body;
    
    const course = await Course.findById(req.params.id);
    
    if (course) {
      // Verify course belongs to faculty
      if (course.instructor.toString() !== req.user._id.toString()) {
        res.status(401);
        throw new Error('Not authorized to update this course');
      }
      
      course.title = title || course.title;
      course.description = description || course.description;
      course.duration = duration || course.duration;
      course.isCommonCourse = isCommonCourse === 'true' || course.isCommonCourse;
      
      const updatedCourse = await course.save();
      res.json(updatedCourse);
    } else {
      res.status(404);
      throw new Error('Course not found');
    }
  })
);

// @desc    Delete a course
// @route   DELETE /api/courses/:id
// @access  Private/Faculty
router.delete(
  '/:id',
  protect,
  faculty,
  asyncHandler(async (req, res) => {
    const course = await Course.findById(req.params.id);
    
    if (course) {
      // Verify course belongs to faculty
      if (course.instructor.toString() !== req.user._id.toString()) {
        res.status(401);
        throw new Error('Not authorized to delete this course');
      }
      
      await course.remove();
      res.json({ message: 'Course removed' });
    } else {
      res.status(404);
      throw new Error('Course not found');
    }
  })
);

// @desc    Get faculty courses
// @route   GET /api/courses/faculty
// @access  Private/Faculty
router.get(
  '/faculty/me',
  protect,
  faculty,
  asyncHandler(async (req, res) => {
    const courses = await Course.find({ instructor: req.user._id });
    res.json(courses);
  })
);

// @desc    Get student enrolled courses
// @route   GET /api/courses/enrolled
// @access  Private
router.get(
  '/enrolled/me',
  protect,
  asyncHandler(async (req, res) => {
    const courses = await Course.find({ enrolledStudents: req.user._id }).populate('instructor', 'name');
    res.json(courses);
  })
);

// @desc    Enroll in a course
// @route   POST /api/courses/:id/enroll
// @access  Private
router.post(
  '/:id/enroll',
  protect,
  asyncHandler(async (req, res) => {
    const course = await Course.findById(req.params.id);
    
    if (course) {
      // Check if already enrolled
      if (course.enrolledStudents.includes(req.user._id)) {
        res.status(400);
        throw new Error('Already enrolled in this course');
      }
      
      course.enrolledStudents.push(req.user._id);
      await course.save();
      
      res.json({ message: 'Successfully enrolled in course' });
    } else {
      res.status(404);
      throw new Error('Course not found');
    }
  })
);

export default router;